package com.lucidplugins.inferno.displaymodes;

public enum InfernoPrayerDisplayMode
{
	PRAYER_TAB,
	BOTTOM_RIGHT,
	BOTH
}
