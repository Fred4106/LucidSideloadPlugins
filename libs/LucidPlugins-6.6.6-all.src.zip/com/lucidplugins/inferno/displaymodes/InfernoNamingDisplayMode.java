package com.lucidplugins.inferno.displaymodes;

public enum InfernoNamingDisplayMode
{
	SIMPLE,
	COMPLEX
}
